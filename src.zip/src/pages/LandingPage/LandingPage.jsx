import React from "react";

export default function LandingPage() {
  return <div style={{ display: "flex", background: "E1D6E8" }}>Hey!</div>;
}
